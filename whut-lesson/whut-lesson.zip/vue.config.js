module.exports = {
    publicPath:'./'
}